<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'DashboardController::index');
$routes->get('/login', 'LoginController::index');
$routes->get('/register', 'LoginController::register');
$routes->get('/dashboard', 'DashboardController::index');
$routes->get('/borrowedlist', 'BorrowBooksController::index');
$routes->get('/register', 'LoginController::register');


$routes->get('/book/add', 'DashboardController::add');
$routes->post('/book/store', 'DashboardController::store');
$routes->get('/book/edit/(:any)', 'DashboardController::edit/$1');
$routes->post('/book/update/(:any)', 'DashboardController::update/$1');
$routes->get('/book/delete/(:any)', 'DashboardController::delete/$1');

$routes->get('/borrow/add', 'BorrowBooksController::add');
$routes->post('/borrow/store', 'BorrowBooksController::store');
$routes->get('/borrow/edit/(:any)', 'BorrowBooksController::edit/$1');
$routes->post('/borrow/update/(:any)', 'BorrowBooksController::update/$1');
$routes->get('/borrow/delete/(:any)', 'BorrowBooksController::delete/$1');


