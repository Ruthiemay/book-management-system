<?php

namespace App\Models;

use CodeIgniter\Model;

class BorrowBookModel extends Model
{
    protected $table            = 'borrow_book';
    protected $primaryKey       = 'stud_id';
    protected $allowedFields = ['stud_id', 'name', 'book_name', 'date_returned'];
}
