<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class LoginController extends BaseController
{
    public function index()
    {
        //
        return view('login');
    }

    public function register()
    {
        return 'this is for register';
    }
}
