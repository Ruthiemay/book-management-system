<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\BookModel;

class DashboardController extends BaseController
{
    public function index()
    {
        $bookModel = new BookModel();
        $data['books'] = $bookModel->findAll();
        return view('dashboard', $data);
    }
    
    public function add()
    {
        return view('book_add');
    }

    public function store()
    {
        helper(['form', 'url']);

        $bookModel = new BookModel();
        $bookModel->insert([
            'book_name'       => $this->request->getPost('book_name'),
            'author'          => $this->request->getPost('author'),
            'year_published'  => $this->request->getPost('year_published'),
        ]);

        return redirect()->to('/dashboard')->with('success', 'Book added successfully');
    }

    public function edit(string $id)
    {
        $bookModel = new BookModel();
        $data['book'] = $bookModel->find($id);
        return view('book_edit', $data);
    }

    public function update(string $id)
    {
        helper(['form', 'url']);
        $bookModel = new BookModel();

        $bookModel->update($id, [
            'book_name'       => $this->request->getPost('book_name'),
            'author'          => $this->request->getPost('author'),
            'year_published'  => $this->request->getPost('year_published'),
        ]);

        return redirect()->to('/dashboard')->with('success', 'Book updated successfully');
    }

    public function delete(string $id)
    {
        $bookModel = new BookModel();
        $bookModel->delete($id);
        return redirect()->to('/dashboard')->with('success', 'Book deleted successfully');
    }
}
