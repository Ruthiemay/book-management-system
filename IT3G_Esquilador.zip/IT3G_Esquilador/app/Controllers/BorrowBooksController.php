<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\BorrowBookModel; 

class BorrowBooksController extends BaseController
{
    public function index()
    {
        $borrowBookModel = new BorrowBookModel();
        $data['borrow_book'] = $borrowBookModel->findAll();
        return view('borrowed_list', $data);
    }
    
    public function add()
    {
        return view('borrowbook_add');
    }

    public function store()
    {
        helper(['form', 'url']);

        $borrowBookModel = new BorrowBookModel();
        $borrowBookModel->insert([
            'name'           => $this->request->getPost('name'),
            'book_name'      => $this->request->getPost('book_name'),
            'date_returned'  => $this->request->getPost('date_returned'),
        ]);

        return redirect()->to('/borrowedlist')->with('success', 'Book borrowed successfully');
    }

    public function edit($stud_id)
    {
        $borrowBookModel = new BorrowBookModel();
        $data['borrowbook'] = $borrowBookModel->find($stud_id);
        return view('borrowbook_edit', $data);
    }

    public function update($stud_id)
    {
        helper(['form', 'url']);
        $borrowBookModel = new BorrowBookModel();

        $borrowBookModel->update($stud_id, [
            'stud_id'        => $this->request->getPost('stud_id'), 
            'name'           => $this->request->getPost('name'),
            'book_name'      => $this->request->getPost('book_name'),
            'date_returned'  => $this->request->getPost('date_returned'),
        ]);

        return redirect()->to('/borrowedlist')->with('success', 'Borrowed book updated successfully');
    }

    public function delete($stud_id)
    {
        $borrowBookModel = new BorrowBookModel();
        $borrowBookModel->delete($stud_id);
        return redirect()->to('/borrowedlist')->with('success', 'Borrowed book deleted successfully');
    }
}