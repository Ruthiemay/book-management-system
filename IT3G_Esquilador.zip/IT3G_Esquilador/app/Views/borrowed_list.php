<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Borrowed List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
            text-align: center;
        }
        .container {
            max-width: 900px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #333;
        }
        .buttons {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        .btn {
            padding: 10px 15px;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: 0.3s;
        }
        .btn-add {
            background-color: #4CAF50;
        }
        .btn-dashboard {
            background-color: #2196F3;
        }
        .btn:hover {
            opacity: 0.8;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background: #4CAF50;
            color: white;
        }
        .actions a {
            padding: 5px 10px;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            margin: 2px;
            display: inline-block;
        }
        .edit {
            background-color: #ff9800;
        }
        .delete {
            background-color: #f44336;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>📖 Borrowed Book List</h1>
        <div class="buttons">
            <a href="<?= site_url('/borrow/add') ?>" class="btn btn-add">➕ Add New</a>
            <a href="<?= site_url('/dashboard') ?>" class="btn btn-dashboard">⬅ Back</a>
        </div>

        <table>
            <tr>
                <th>Student ID</th>
                <th>Name</th>
                <th>Book Name</th>
                <th>Date Returned</th>
                <th>Actions</th> 
            </tr>
            <?php foreach ($borrow_book as $borrowbook): ?>
                <tr>
                    <td><?= $borrowbook['stud_id']; ?></td>
                    <td><?= $borrowbook['name']; ?></td>
                    <td><?= $borrowbook['book_name']; ?></td>
                    <td><?= $borrowbook['date_returned']; ?></td>
                    <td class="actions"> 
                        <a href="<?= site_url('/borrow/edit/' . $borrowbook['stud_id']) ?>" class="edit">✏️ Edit</a>
                        <a href="<?= site_url('/borrow/delete/' . $borrowbook['stud_id']) ?>" class="delete" onclick="return confirm('Are you sure you want to delete this borrowbook?')">🗑️ Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>

    </div>
</body>
</html>
