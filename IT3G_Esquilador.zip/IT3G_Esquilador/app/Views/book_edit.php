<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background: #fff;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
            text-align: center;
        }
        .container h2 {
            color: #333;
            font-size: 22px;
            margin-bottom: 20px;
            font-weight: 600;
        }
        .form-group {
            text-align: left;
            margin-bottom: 15px;
        }
        label {
            font-weight: 600;
            color: #555;
            display: block;
            margin-bottom: 5px;
        }
        input {
            width: 95%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            background-color: #fff;
            transition: border-color 0.3s ease-in-out;
        }
        input:focus {
            border-color: #007bff;
            outline: none;
        }
        button {
            width: 100%;
            background-color: #007bff;
            color: white;
            border: none;
            padding: 12px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #0056b3;
        }
        .back-link {
            display: inline-block;
            margin-top: 15px;
            text-decoration: none;
            color: #555;
            font-size: 14px;
            font-weight: 500;
        }
        .back-link:hover {
            text-decoration: underline;
        }
        .icon {
            font-size: 24px;
            color: #007bff;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="icon"></div>
        <h2>✏️ Edit Book Details</h2>
        <form action="<?= site_url('book/update/' . $book['id']) ?>" method="post">
            <div class="form-group">
                <label for="book_name">Book Name</label>
                <input type="text" name="book_name" id="book_name" value="<?= $book['book_name'] ?>" required>
            </div>
            <div class="form-group">
                <label for="author">Author</label>
                <input type="text" name="author" id="author" value="<?= $book['author'] ?>" required>
            </div>
            <div class="form-group">
                <label for="year_published">Year Published</label>
                <input type="number" name="year_published" id="year_published" value="<?= $book['year_published'] ?>" required>
            </div>
            <button type="submit">Update Book</button>
        </form>
        <a href="<?= site_url('/dashboard') ?>" class="back-link">⬅ Back to Dashboard</a>
    </div>
</body>

</html>
