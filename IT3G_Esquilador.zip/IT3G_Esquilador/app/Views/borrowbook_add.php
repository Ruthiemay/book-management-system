<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Borrowed Book</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
            text-align: center;
        }
        h2 {
            color: #333;
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 20px;
        }
        .form-group {
            text-align: left;
            margin-bottom: 15px;
        }
        label {
            font-weight: 600;
            color: #555;
            display: block;
            margin-bottom: 5px;
        }
        input {
            width: 95%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            background-color: #fff;
            transition: border-color 0.3s ease-in-out;
        }
        input:focus {
            border-color: #007bff;
            outline: none;
        }
        button {
            width: 100%;
            background-color: #007bff;
            color: white;
            border: none;
            padding: 12px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #0056b3;
        }
        .back-link {
            display: inline-block;
            margin-top: 15px;
            text-decoration: none;
            color: #555;
            font-size: 14px;
            font-weight: 500;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>➕ Borrow a Book</h2>
        <form action="<?= site_url('borrow/store') ?>" method="post">
            <div class="form-group">
                <label for="stud_id">Student ID</label>
                <input type="text" id="stud_id" name="stud_id" required>
            </div>
            <div class="form-group">
                <label for="name">Student Name</label>
                <input type="text" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label for="book_name">Book Name</label>
                <input type="text" id="book_name" name="book_name" required>
            </div>
            <div class="form-group">
                <label for="date_returned">Return Date</label>
                <input type="date" id="date_returned" name="date_returned" required>
            </div>
            <button type="submit">Add Borrowed Book</button>
        </form>
        <a href="<?= site_url('/borrowedlist') ?>" class="back-link">⬅ Back to Dashboard</a>
    </div>
</body>
</html>
